package co.edu.uniquindio.poo.notificaciones;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class HelloController {
    // Asegúrate que estas variables tengan @FXML
    @FXML
    private ComboBox<String> userTypeComboBox;
    @FXML private ComboBox<String> notificationTypeComboBox;
    @FXML private ComboBox<String> filterComboBox;
    @FXML private ComboBox<String> userSelectionComboBox;
    @FXML private TextField usernameField;
    @FXML private Button createUserButton;
    @FXML private Button sendNotificationButton;
    @FXML private TextArea outputArea;
    @FXML private TextArea messageArea;
    @FXML private CheckBox priorityCheckBox;
    @FXML private DatePicker scheduleDatePicker;

    // Chain of Responsibility pattern
    private NotificationFilter filterChain;

    // Command pattern
    private NotificationInvoker invoker = new NotificationInvoker();

    // Store created users
    private Map<String, User> users = new HashMap<>();

    @FXML
    public void initialize() {
        // Verifica que los ComboBox no son null
        Objects.requireNonNull(userTypeComboBox, "userTypeComboBox no fue inyectado");
        Objects.requireNonNull(notificationTypeComboBox, "notificationTypeComboBox no fue inyectado");
        Objects.requireNonNull(userSelectionComboBox, "userSelectionComboBox no fue inyectado");
        Objects.requireNonNull(outputArea, "outputArea no fue inyectado");

        // Llena los ComboBox
        userTypeComboBox.getItems().setAll("Administrador", "Cliente", "Invitado");
        notificationTypeComboBox.getItems().setAll("Email", "SMS", "Notificación Push");
        filterComboBox.getItems().setAll("Sin filtro", "Filtrar mensajes vacíos", "Filtrar usuarios bloqueados", "Ambos filtros");

        // Inicializa el ComboBox de selección de usuario
        userSelectionComboBox.setPromptText("Seleccione un usuario...");

        // Configura los botones
        createUserButton.setOnAction(e -> createUser());
        sendNotificationButton.setOnAction(e -> sendNotification());

        // Debug visual
        userTypeComboBox.setVisible(true);
        notificationTypeComboBox.setVisible(true);

        // Inicializa el Chain of Responsibility
        setupFilterChain();

        // Inicializa el registro de actividad
        // Los mensajes de inicialización han sido removidos
    }

    /**
     * Configura la cadena de filtros para el patrón Chain of Responsibility.
     */
    private void setupFilterChain() {
        EmptyMessageFilter emptyFilter = new EmptyMessageFilter();
        BlockedUserFilter blockedFilter = new BlockedUserFilter();

        // Configura la cadena: emptyFilter -> blockedFilter
        emptyFilter.setNext(blockedFilter);

        // Guarda la referencia al inicio de la cadena
        filterChain = emptyFilter;

        // Para demostración, bloquea un usuario de ejemplo
        blockedFilter.blockUser("usuarioBloqueado");
    }

    private void createUser() {
        String userType = userTypeComboBox.getValue();
        String username = usernameField.getText();

        if (userType == null || username == null || username.trim().isEmpty()) {
            logMessage("Error: Seleccione un tipo de usuario y proporcione un nombre de usuario");
            return;
        }

        // Determina el tipo de notificación preferido
        String notificationType = notificationTypeComboBox.getValue();
        if (notificationType == null) {
            notificationType = "Email"; // Valor por defecto
        }

        // Crea la estrategia de notificación apropiada
        NotificationStrategy strategy;
        switch (notificationType) {
            case "SMS":
                strategy = new SMSNotification();
                break;
            case "Notificación Push":
                strategy = new PushNotification();
                break;
            default:
                strategy = new EmailNotification();
                break;
        }

        // Crea el usuario según su tipo
        User user;
        switch (userType) {
            case "Administrador":
                user = new AdminUser(username, strategy);
                break;
            case "Invitado":
                user = new GuestUser(username, strategy);
                break;
            default:
                user = new ClientUser(username, strategy);
                break;
        }

        // Almacena el usuario
        users.put(username, user);

        // Añade el usuario al ComboBox de selección
        userSelectionComboBox.getItems().add(username);

        String message = "Usuario creado: " + username + " (Tipo: " + userType + ", Notificación: " + notificationType + ")";
        logMessage(message);
    }

    private void sendNotification() {
        String message = messageArea.getText();
        String username = userSelectionComboBox.getValue();

        if (username == null) {
            logMessage("Error: Seleccione un usuario para enviar la notificación");
            return;
        }

        // Obtiene el usuario del mapa
        User user = users.get(username);
        if (user == null) {
            logMessage("Error: El usuario '" + username + "' no existe. Créelo primero.");
            return;
        }

        // Determina qué filtros aplicar según la selección
        String filterOption = filterComboBox.getValue();
        NotificationFilter filterToUse = null;

        if (filterOption != null) {
            switch (filterOption) {
                case "Filtrar mensajes vacíos":
                    filterToUse = new EmptyMessageFilter();
                    break;
                case "Filtrar usuarios bloqueados":
                    filterToUse = new BlockedUserFilter();
                    break;
                case "Ambos filtros":
                    filterToUse = filterChain;
                    break;
                default:
                    // Sin filtro
                    break;
            }
        }

        // Crea el comando
        NotificationCommand command = new SendNotificationCommand(user, message, filterToUse);

        // Añade el comando al invoker
        invoker.addCommand(command);

        // Ejecuta el comando
        invoker.executeNext();

        // Registra la acción
        logMessage("Comando creado para enviar notificación a " + username);
        logMessage("Historial de comandos: " + invoker.getCommandHistory().size() + " comandos ejecutados");

        // Mensaje de confirmación de envío
        logMessage("✅ Mensaje enviado correctamente a " + username);
    }

    private void logMessage(String message) {
        // Registrar en el archivo de log
        NotificationLogger.getInstance().log(message);

        // Mostrar en el área de registro de actividad
        if (outputArea != null) {
            outputArea.appendText(message + "\n");
        }
    }
}
