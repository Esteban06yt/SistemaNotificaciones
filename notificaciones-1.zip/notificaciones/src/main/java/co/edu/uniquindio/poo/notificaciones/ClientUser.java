package co.edu.uniquindio.poo.notificaciones;

public class ClientUser extends User {
    public ClientUser(String username, NotificationStrategy strategy) {
        super(username, strategy);
    }

    @Override
    protected String formatMessage(String message) {
        return "Estimado cliente: " + message;
    }
}
