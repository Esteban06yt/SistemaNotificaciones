package co.edu.uniquindio.poo.notificaciones;
// Interfaz para el patrón Strategy
public interface NotificationStrategy {
    void sendNotification(String message, String user);

    void send(String formatted, String username);
}

