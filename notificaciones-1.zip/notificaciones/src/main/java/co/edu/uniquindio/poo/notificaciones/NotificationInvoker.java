package co.edu.uniquindio.poo.notificaciones;

import java.util.ArrayList;
import java.util.List;

/**
 * Invoker class for the Command pattern.
 * Responsible for executing notification commands.
 */
public class NotificationInvoker {
    private List<NotificationCommand> commandQueue = new ArrayList<>();
    private List<NotificationCommand> commandHistory = new ArrayList<>();
    
    /**
     * Adds a command to the queue.
     * 
     * @param command The command to add
     */
    public void addCommand(NotificationCommand command) {
        commandQueue.add(command);
    }
    
    /**
     * Executes all commands in the queue.
     */
    public void executeAll() {
        for (NotificationCommand command : commandQueue) {
            command.execute();
            commandHistory.add(command);
        }
        commandQueue.clear();
    }
    
    /**
     * Executes the next command in the queue.
     */
    public void executeNext() {
        if (!commandQueue.isEmpty()) {
            NotificationCommand command = commandQueue.remove(0);
            command.execute();
            commandHistory.add(command);
        }
    }
    
    /**
     * Gets the command history.
     * 
     * @return The list of executed commands
     */
    public List<NotificationCommand> getCommandHistory() {
        return new ArrayList<>(commandHistory);
    }
    
    /**
     * Gets the command queue.
     * 
     * @return The list of pending commands
     */
    public List<NotificationCommand> getCommandQueue() {
        return new ArrayList<>(commandQueue);
    }
}