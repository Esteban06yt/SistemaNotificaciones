package co.edu.uniquindio.poo.notificaciones;

/**
 * Event listener that logs events to the notification logger.
 * Implements the Observer pattern.
 */
public class LoggerListener implements EventListener {
    private NotificationLogger logger;
    
    public LoggerListener() {
        this.logger = NotificationLogger.getInstance();
    }
    
    @Override
    public void update(Event event) {
        logger.log("Event received: " + event);
    }
    
    @Override
    public boolean isInterestedIn(String eventType) {
        // This listener is interested in all events
        return true;
    }
    
    @Override
    public void update(String eventType, String data) {
        logger.log("Event received: " + eventType + " - " + data);
    }
}