package co.edu.uniquindio.poo.notificaciones;

public class SMSNotification implements NotificationStrategy {
    @Override
    public void sendNotification(String message, String user) {
        System.out.println("Enviando SMS a " + user + ": " + message);
    }

    @Override
    public void send(String formatted, String username) {
        sendNotification(formatted, username);
    }
}
