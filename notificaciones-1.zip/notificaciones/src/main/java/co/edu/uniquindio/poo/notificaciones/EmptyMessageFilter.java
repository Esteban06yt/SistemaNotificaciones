package co.edu.uniquindio.poo.notificaciones;

/**
 * Filter that checks if a message is empty.
 * Part of the Chain of Responsibility pattern.
 */
public class EmptyMessageFilter extends NotificationFilter {
    
    @Override
    protected boolean shouldProcess(User user, String message) {
        if (message == null || message.trim().isEmpty()) {
            System.out.println("Notification rejected: Empty message");
            return false;
        }
        return true;
    }
}