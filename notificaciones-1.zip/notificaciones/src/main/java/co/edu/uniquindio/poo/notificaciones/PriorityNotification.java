package co.edu.uniquindio.poo.notificaciones;


// Nueva clase
public abstract class PriorityNotification implements NotificationStrategy {
    private NotificationStrategy wrapped;
    private boolean isUrgent;

    public PriorityNotification(NotificationStrategy wrapped, boolean isUrgent) {
        this.wrapped = wrapped;
        this.isUrgent = isUrgent;
    }

    @Override
    public void sendNotification(String message, String user) {
        String prefix = isUrgent ? "[URGENTE] " : "[NORMAL] ";
        wrapped.sendNotification(prefix + message, user);
    }
}