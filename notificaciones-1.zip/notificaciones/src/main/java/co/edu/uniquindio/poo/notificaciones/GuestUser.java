package co.edu.uniquindio.poo.notificaciones;

public class GuestUser extends User {
    public GuestUser(String username, NotificationStrategy strategy) {
        super(username, strategy);
    }

    @Override
    protected String formatMessage(String message) {
        return "Hola invitado: " + message.toLowerCase();
    }
}
