package co.edu.uniquindio.poo.notificaciones;

// Observer
public interface EventListener {
    /**
     * Called when an event occurs.
     * 
     * @param event The event that occurred
     */
    void update(Event event);

    /**
     * Checks if this listener is interested in the given event type.
     * 
     * @param eventType The event type to check
     * @return true if this listener is interested in the event type, false otherwise
     */
    boolean isInterestedIn(String eventType);

    /**
     * Called when an event occurs with the given type and data.
     * 
     * @param eventType The type of the event
     * @param data The data associated with the event
     */
    void update(String eventType, String data);
}
