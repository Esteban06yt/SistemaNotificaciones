package co.edu.uniquindio.poo.notificaciones;

/**
 * Represents an event in the system.
 * Events can be of different types and contain data.
 */
public class Event {
    private String type;
    private String data;
    private String source;

    /**
     * Creates a new event.
     * 
     * @param type The type of the event
     * @param data The data associated with the event
     * @param source The source of the event
     */
    public Event(String type, String data, String source) {
        this.type = type;
        this.data = data;
        this.source = source;
    }

    /**
     * Gets the type of the event.
     * 
     * @return The event type
     */
    public String getType() {
        return type;
    }

    /**
     * Gets the data associated with the event.
     * 
     * @return The event data
     */
    public String getData() {
        return data;
    }

    /**
     * Gets the source of the event.
     * 
     * @return The event source
     */
    public String getSource() {
        return source;
    }

    @Override
    public String toString() {
        return "Event{" +
                "type='" + type + '\'' +
                ", data='" + data + '\'' +
                ", source='" + source + '\'' +
                '}';
    }
}