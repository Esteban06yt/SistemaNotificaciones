package co.edu.uniquindio.poo.notificaciones;

import java.util.HashSet;
import java.util.Set;

/**
 * Filter that checks if a user is blocked.
 * Part of the Chain of Responsibility pattern.
 */
public class BlockedUserFilter extends NotificationFilter {
    private Set<String> blockedUsers = new HashSet<>();
    
    /**
     * Blocks a user from receiving notifications.
     * 
     * @param username The username to block
     */
    public void blockUser(String username) {
        blockedUsers.add(username);
    }
    
    /**
     * Unblocks a user to allow them to receive notifications.
     * 
     * @param username The username to unblock
     */
    public void unblockUser(String username) {
        blockedUsers.remove(username);
    }
    
    @Override
    protected boolean shouldProcess(User user, String message) {
        if (blockedUsers.contains(user.getUsername())) {
            System.out.println("Notification rejected: User " + user.getUsername() + " is blocked");
            return false;
        }
        return true;
    }
}