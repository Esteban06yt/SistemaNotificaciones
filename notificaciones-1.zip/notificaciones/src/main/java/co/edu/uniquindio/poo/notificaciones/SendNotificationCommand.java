package co.edu.uniquindio.poo.notificaciones;

/**
 * Concrete command for sending a notification.
 * Part of the Command pattern.
 */
public class SendNotificationCommand implements NotificationCommand {
    private User user;
    private String message;
    private NotificationFilter filter;
    
    /**
     * Creates a new command to send a notification.
     * 
     * @param user The user to send the notification to
     * @param message The message to send
     * @param filter The filter chain to apply before sending
     */
    public SendNotificationCommand(User user, String message, NotificationFilter filter) {
        this.user = user;
        this.message = message;
        this.filter = filter;
    }
    
    /**
     * Creates a new command to send a notification without filtering.
     * 
     * @param user The user to send the notification to
     * @param message The message to send
     */
    public SendNotificationCommand(User user, String message) {
        this(user, message, null);
    }
    
    @Override
    public void execute() {
        if (filter == null || filter.process(user, message)) {
            user.sendMessage(message);
        }
    }
    
    @Override
    public User getUser() {
        return user;
    }
    
    @Override
    public String getMessage() {
        return message;
    }
}