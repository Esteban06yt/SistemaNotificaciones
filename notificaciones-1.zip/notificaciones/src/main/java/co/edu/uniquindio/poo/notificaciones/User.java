package co.edu.uniquindio.poo.notificaciones;
// User.java
public abstract class User {
    protected String username;
    protected NotificationStrategy notificationStrategy;

    public User(String username, NotificationStrategy strategy) {
        this.username = username;
        this.notificationStrategy = strategy;
    }

    public final void sendMessage(String message) {
        String formatted = formatMessage(message);
        notificationStrategy.send(formatted, username);
    }

    /**
     * Gets the username of this user.
     * 
     * @return The username
     */
    public String getUsername() {
        return username;
    }

    protected abstract String formatMessage(String message);
}

// AdminUser.java
