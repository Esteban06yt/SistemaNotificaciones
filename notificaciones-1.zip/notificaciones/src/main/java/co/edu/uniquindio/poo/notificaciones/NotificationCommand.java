package co.edu.uniquindio.poo.notificaciones;

/**
 * Interface for the Command pattern.
 * Represents a command that can be executed to send a notification.
 */
public interface NotificationCommand {
    
    /**
     * Executes the command to send a notification.
     */
    void execute();
    
    /**
     * Gets the user associated with this command.
     * 
     * @return The user
     */
    User getUser();
    
    /**
     * Gets the message associated with this command.
     * 
     * @return The message
     */
    String getMessage();
}