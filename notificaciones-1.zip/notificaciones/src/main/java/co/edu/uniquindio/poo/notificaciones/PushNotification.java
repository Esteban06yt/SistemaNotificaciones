package co.edu.uniquindio.poo.notificaciones;

public class PushNotification implements NotificationStrategy {
    @Override
    public void sendNotification(String message, String user) {
        System.out.println("Enviando notificación push a " + user + ": " + message);
    }

    @Override
    public void send(String formatted, String username) {
        sendNotification(formatted, username);
    }
}
