package co.edu.uniquindio.poo.notificaciones;

// Subclases concretas
public class AdminUser extends User {
    public AdminUser(String username, NotificationStrategy strategy) {
        super(username, strategy);
    }

    @Override
    protected String formatMessage(String message) {
        return "[ADMIN PRIORITY] " + message.toUpperCase();
    }
}
