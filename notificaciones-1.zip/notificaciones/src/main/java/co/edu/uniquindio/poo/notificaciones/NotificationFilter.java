package co.edu.uniquindio.poo.notificaciones;

/**
 * Abstract base class for notification filters in a Chain of Responsibility pattern.
 * Each filter can process a notification or pass it to the next filter in the chain.
 */
public abstract class NotificationFilter {
    private NotificationFilter nextFilter;

    /**
     * Sets the next filter in the chain.
     * 
     * @param nextFilter The next filter to process the notification
     * @return The next filter for method chaining
     */
    public NotificationFilter setNext(NotificationFilter nextFilter) {
        this.nextFilter = nextFilter;
        return nextFilter;
    }

    /**
     * Processes the notification or passes it to the next filter.
     * 
     * @param user The user receiving the notification
     * @param message The message content
     * @return true if the notification should be sent, false otherwise
     */
    public boolean process(User user, String message) {
        if (shouldProcess(user, message)) {
            return nextFilter != null ? nextFilter.process(user, message) : true;
        }
        return false;
    }

    /**
     * Determines whether the notification should be processed further.
     * 
     * @param user The user receiving the notification
     * @param message The message content
     * @return true if the notification should be processed further, false otherwise
     */
    protected abstract boolean shouldProcess(User user, String message);
}
