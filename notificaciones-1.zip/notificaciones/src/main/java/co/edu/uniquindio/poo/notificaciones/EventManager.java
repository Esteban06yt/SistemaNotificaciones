package co.edu.uniquindio.poo.notificaciones;

import java.util.ArrayList;
import java.util.List;

// EventManager.java
public class EventManager {
    private List<EventListener> listeners = new ArrayList<>();
    private String source = "System";

    public EventManager() {
    }

    public EventManager(String source) {
        this.source = source;
    }

    public void subscribe(EventListener listener) {
        listeners.add(listener);
    }

    public void unsubscribe(EventListener listener) {
        listeners.remove(listener);
    }

    public void notify(String eventType, String data) {
        Event event = new Event(eventType, data, source);
        for (EventListener listener : listeners) {
            if (listener.isInterestedIn(eventType)) {
                listener.update(event);
                listener.update(eventType, data);
            }
        }
    }
}

// NotificationService.java
