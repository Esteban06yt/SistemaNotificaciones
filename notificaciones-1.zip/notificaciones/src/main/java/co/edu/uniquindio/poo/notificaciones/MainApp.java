package co.edu.uniquindio.poo.notificaciones;

/**
 * Main application class that demonstrates the notification system.
 */
public class MainApp {

    public static void main(String[] args) {
        // Create notification strategies
        NotificationStrategy emailStrategy = new EmailNotification();
        NotificationStrategy smsStrategy = new SMSNotification();
        NotificationStrategy pushStrategy = new PushNotification();

        // Create users with different strategies
        User adminUser = new AdminUser("admin", emailStrategy);
        User clientUser = new ClientUser("client", smsStrategy);
        User guestUser = new GuestUser("guest", pushStrategy);

        // Create notification filters
        EmptyMessageFilter emptyFilter = new EmptyMessageFilter();
        BlockedUserFilter blockedFilter = new BlockedUserFilter();

        // Chain filters together
        emptyFilter.setNext(blockedFilter);

        // Block a user
        blockedFilter.blockUser("guest");

        // Create notification commands
        NotificationCommand adminCommand = new SendNotificationCommand(adminUser, "System update scheduled", emptyFilter);
        NotificationCommand clientCommand = new SendNotificationCommand(clientUser, "New promotion available", emptyFilter);
        NotificationCommand guestCommand = new SendNotificationCommand(guestUser, "Welcome to our system", emptyFilter);
        NotificationCommand emptyCommand = new SendNotificationCommand(adminUser, "", emptyFilter);

        // Create notification invoker
        NotificationInvoker invoker = new NotificationInvoker();

        // Add commands to invoker
        invoker.addCommand(adminCommand);
        invoker.addCommand(clientCommand);
        invoker.addCommand(guestCommand);
        invoker.addCommand(emptyCommand);

        // Execute all commands
        System.out.println("Executing all notification commands:");
        invoker.executeAll();

        // Create event manager for observer pattern
        EventManager eventManager = new EventManager("NotificationSystem");

        // Create a logger listener that listens for events
        LoggerListener loggerListener = new LoggerListener();

        // Subscribe the logger listener to the event manager
        eventManager.subscribe(loggerListener);

        // Notify about events
        System.out.println("\nNotifying about events:");
        eventManager.notify("USER_LOGIN", "admin logged in");
        eventManager.notify("SYSTEM_ALERT", "Disk space low");

        // Unblock the guest user
        blockedFilter.unblockUser("guest");

        // Create a new command for the guest user
        NotificationCommand newGuestCommand = new SendNotificationCommand(guestUser, "Your trial period is ending", emptyFilter);

        // Add and execute the new command
        System.out.println("\nExecuting new command after unblocking user:");
        invoker.addCommand(newGuestCommand);
        invoker.executeNext();
    }
}
