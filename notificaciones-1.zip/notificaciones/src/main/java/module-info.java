module co.edu.uniquindio.poo.notificaciones {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens co.edu.uniquindio.poo.notificaciones to javafx.fxml;
    exports co.edu.uniquindio.poo.notificaciones;
}